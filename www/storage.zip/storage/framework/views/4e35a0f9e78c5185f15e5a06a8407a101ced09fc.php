    <?php $__env->startSection('admin_content'); ?>
        <div class="row" style="margin-top:5px;">
            <?php $__currentLoopData = $single_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form method="post" action="<?php echo e(url('/edit', $v_s->id)); ?>" >
            <?php echo e(csrf_field()); ?>

            <div class="col-sm-10">
                <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
                <input  class="form-control" id="edit_show" name="title"  value='<?php echo e($v_s->title); ?>' placeholder="Title">
            </div>
            <div class="col-sm-1">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
            </form>
            <div class="col-sm-1">
            <form action="<?php echo e(action('ListsController@destroy', $v_s->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input name="_method" type="hidden" value="DELETE">
                <button class="btn btn-danger" type="submit">Delete</button>
            </form>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12">          
            <table class="table table-striped table-advance table-hover">
                <thead>
                <tr>
                <th>Tasks <button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#myModal">Add Task</button>
                </th><th></th>
                </tr>
                <tr>
                <th>Summary</th>
                <th class="hidden-phone">Priority</th>
                <th> Type</th>
                <th>Date</th>
                <th><i class=" fa fa-edit"></i> Status</th>
                <th><i class=" fa fa-edit"></i> Action</th>
                </tr>
                </thead>
               
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                <tr>
                <td><a href="<?php echo e(URL::to('/editTask/'.$v_task->id)); ?>"><?php echo e(str_limit($v_task->title,20)); ?></a></td>
                <td>  
                <?php echo $__env->make('include.priority', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                <td><?php echo e($v_task->type); ?></td>
                <td><?php echo e($v_task->date); ?></td>
                <td>
                <?php echo $__env->make('include.status', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </td>
                <td>
                <a href="<?php echo e(URL::to('/editTask/'.$v_task->id)); ?>" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                <a href="<?php echo e(URL::to('/delete-task/'.$v_task->id)); ?>"> <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button></a>           
                </td>
                </tr>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            </div>
            <?php echo $__env->make('site.taskCreate', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>            
        </div> 
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('lib/admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>