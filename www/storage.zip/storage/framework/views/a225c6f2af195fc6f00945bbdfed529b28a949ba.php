<?php $__env->startSection('main'); ?>
 <section id="main-content">
          <section class="wrapper">
<div id="login-page">
	<div class="container">
		<form class="form-login" method="POST" action="<?php echo e(route('register')); ?>"  enctype="multipart/form-data">
    		<?php echo csrf_field(); ?>
		    <h2 class="form-login-heading">Create Account</h2>
		    <div class="login-wrap">
		        <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>"  placeholder="User name" required autofocus >
		        <?php if($errors->has('name')): ?>
                <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('name')); ?></strong> </span>
                <?php endif; ?> <br>
				<input  id="email" type="email" class="form-control"  name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
		        <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert"> <strong><?php echo e($errors->first('email')); ?></strong> </span>
                <?php endif; ?> <br>
				<input  id="image" type="file" class="form-control"  name="image">
		        <?php if($errors->has('image')): ?>
                <span class="invalid-feedback" role="alert"> <strong><?php echo e($errors->first('email')); ?></strong> </span>
                <?php endif; ?> <br>
		    	<input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
				<?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('password')); ?></strong> </span>
                <?php endif; ?> <br>
		        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password" required></br>
		       	<button class="btn btn-theme btn-block" type="submit"><i class="fa fa-lock"></i> Create</button>
		       	<div class="registration">
		            Have an account ?<br/><a class="" href="<?php echo e(route('login')); ?>"> Login</a>
		        </div>
		    </div>
		</form>	  	
	</div>
</div>
</section>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('login'); ?>
  <!--  	<script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/login-bg.jpg", {speed: 500});
    </script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>