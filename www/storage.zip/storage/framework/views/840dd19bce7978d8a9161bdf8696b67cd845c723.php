<?php if($v_task->status=='cencle'): ?>
    <span class="label label-danger label-mini">
    <?php elseif($v_task->status=='done'): ?>
    <span class="label label-success label-mini">
    <?php elseif($v_task->status=='inprogress'): ?>
    <span class="label label-warning label-mini">
    <?php else: ?>
    <span class="label label-info label-mini">
<?php endif; ?> <?php echo e($v_task->status); ?></span>