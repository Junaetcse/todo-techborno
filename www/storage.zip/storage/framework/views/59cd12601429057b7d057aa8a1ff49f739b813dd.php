    <?php $__env->startSection('admin_content'); ?>
        <span class="help-block"></span>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

        </div>
        <?php endif; ?>
    <?php $__currentLoopData = $edit_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form method="post" action="<?php echo e(url('/update', $e_task->id)); ?>" >
                <?php echo e(csrf_field()); ?>

                <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Task Details</h4>
                </div>
                <label class="col-sm-2 col-sm-2 control-label" style="margin-top:20px;">Summary</label>
                <div class="col-sm-10" style="margin-top:20px;">
                    <input type="text" value="<?php echo e($e_task->title); ?>" name="title" class="form-control">
                    <span class="help-block"></span>
                </div>
          
             
                <label class="col-sm-2 col-sm-2 control-label">Type </label>
                <div class="col-sm-10">
                    <select name="type" class="btn btn-default btn-sm">
                        <option value="">Type select</option>
                        <option <?php echo e(old('type', $e_task->type)=="read"? 'selected':''); ?> value="read">Read</option>
                        <option  <?php echo e(old('type', $e_task->type)=="write"? 'selected':''); ?> value="write">Write</option>
                        <option  <?php echo e(old('type', $e_task->type)=="pracital"? 'selected':''); ?> value="pracital">Pracital</option>
                    </select> 
                    <span class="help-block"></span>                             
                </div>
                <label class="col-sm-2 col-sm-2 control-label" style="{margin-top:20px;}">Description</label>
                <div class="col-sm-10">
                    <textarea name="description" class="summernote">
                        <?php echo e($e_task->description); ?>

                    </textarea>
                    <span class="help-block"></span>
                </div>
                <label class="col-sm-2 col-sm-2 control-label">Priority </label>
                <div class="col-sm-10">
                    <select name="priority" class="btn btn-default btn-sm">
						<option value="" >Priority select</option>
						<option  <?php echo e(old('priority', $e_task->priority)=="high"? 'selected':''); ?> value="high">High</option>
						<option  <?php echo e(old('priority', $e_task->priority)=="low"? 'selected':''); ?> value="low">Low</option>
						<option  <?php echo e(old('priority', $e_task->priority)=="medium"? 'selected':''); ?> value="medium">Medium</option>
					</select>    
                    <span class="help-block"></span>                   
                </div>
                <label class="col-sm-2 col-sm-2 control-label">Date</label>
                <div class="col-sm-10">
                    <input value="<?php echo e($e_task->date); ?>"  id="date" name="date" class="form-control" placeholder="MM/DD/YYY" type="date"/>
                    <span class="help-block"></span>
                </div>
                <label class="col-sm-2 col-sm-2 control-label">Status </label>
                <div class="col-sm-10">
                    <select  name="status" class="btn btn-default btn-sm">
						<option value="">Status select</option>
						<option <?php echo e(old('status', $e_task->status)=="inprogress"? 'selected':''); ?> value="inprogress" >In progress</option>
						<option <?php echo e(old('status', $e_task->status)=="done"? 'selected':''); ?> value="done">Done</option>
						<option <?php echo e(old('status', $e_task->status)=="todo"? 'selected':''); ?> value="todo">Todo</option>
                        <option <?php echo e(old('status', $e_task->status)=="cencle"? 'selected':''); ?> value="cencle">Cencle</option>
					</select>        
                    <span class="help-block"></span>                     
                </div>
                <input type="hidden"  name="lists_id" value="<?php echo e($e_task->lists_id); ?>"> </input><br>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" >Update Task</button>
                </div>
            </form>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('lib/admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>