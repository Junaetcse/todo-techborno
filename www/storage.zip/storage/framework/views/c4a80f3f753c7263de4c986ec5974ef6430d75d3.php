<?php $__env->startSection('admin_content'); ?>

    <div class="row">
        <div class="col-lg-12 main-chart">
                   <a href="#"><div class="col-md-3 mb" onclick="toggleVisibility('Menu1');">
                        <div class="white-panel hover">
                            <div class="white-header">
                                <h5>Total Task</h5>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 col-xs-6 goleft">
                                    <p><i class="fa"></i> <?php echo e($totalTask->count()); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                  </a>
                    <a href="#"> <div class="col-md-3 mb" onclick="toggleVisibility('Menu2');">
                        <div class="white-panel hover">
                            <div class="white-header">
                                <h5>Completed Task</h5>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 col-xs-6 goleft">
                                    <p><i class="fa"></i> <?php echo e($completedTask->count()); ?></p>
                                </div>
                            </div>
                        </div>
                    </div> </a>
                 
                  <a href="#"><div class="col-md-3 mb" onclick="toggleVisibility('Menu3');">
                        <div class="white-panel hover">
                            <div class="white-header" href="#">
                                <h5>High Priority Task</h5>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 col-xs-6 goleft">
                                    <p><i class="fa"></i> <?php echo e($priorityTasks->count()); ?></p>
                                </div>
                            </div>
                        </div>
                    </div></a>

                     <a href="#"><div class="col-md-3 mb" onclick="toggleVisibility('Menu4');">
                        <div class="white-panel hover">
                            <div class="white-header">
                                <h5>Upcomming Task</h5>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 col-xs-6 goleft">
                                    <p><i class="fa"></i><?php echo e($upcommingTask->count()); ?></p>
                                </div>
                            </div>
                        </div>
                    </div></a>


         <div id="Menu1">
            <div class="custom-check goleft mt">
                <table id="todo" class="table table-hover custom-check">
                <tbody>
                <h5  style="color:green"><b>Total Task</b></h5>
                <?php $__currentLoopData = $totalTask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>
                <?php echo $__env->make('include.priority', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <a style="margin-left: 20px;" href="<?php echo e(URL::to('/editTask/'.$v_task->id)); ?>">  <?php echo e($v_task->title); ?></a>
                <span style="margin-left: 10px;" class="label label-warning label-mini">
                <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $v_task->updated_at)->diffForHumans()); ?>

                </span>
                <span style="margin-left: 5px; margin-right: 20px" class="label label-default label-mini">
                <?php echo e($v_task->lists->title); ?></span>
                <?php echo $__env->make('include.status', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
        </div>

        <div id="Menu2" style="display: none;">
            <div class="custom-check goleft mt">
                <table id="todo" class="table table-hover custom-check">
                <tbody>
                <h5  style="color:green"><b>Completed Task</b></h5>
                <?php $__currentLoopData = $completedTask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>
              <!--   <?php echo $__env->make('include.priority', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <a style="margin-left: 20px" href="<?php echo e(URL::to('/editTask/'.$v_task->id)); ?>"><?php echo e($v_task->title); ?></a></span>
                <?php if($v_task->status=='done'): ?>
                <span  style="margin-left: 20px" class="label label-success label-mini">Done</span>
                 <?php endif; ?> -->
                <?php echo $__env->make('include.priority', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <a style="margin-left: 20px;" href="<?php echo e(URL::to('/editTask/'.$v_task->id)); ?>">  <?php echo e($v_task->title); ?></a>
                <span style="margin-left: 10px;" class="label label-warning label-mini">
                <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $v_task->updated_at)->diffForHumans()); ?>

                </span>
                <span style="margin-left: 5px; margin-right: 20px" class="label label-default label-mini">
                <?php echo e($v_task->lists->title); ?></span>
                <?php echo $__env->make('include.status', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>    
        </div>
      
        <div id="Menu3" style="display: none;">
            <div class="custom-check goleft mt">
              <table id="todo" class="table table-hover custom-check">
              <tbody>
              <h5  style="color:green"><b>High Priority Task</b></h5>
              <?php $__currentLoopData = $priorityTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td>
              <span class="check  btn-danger btn-xs"> <i class="fa fa-bookmark"></i> </span>
              <a style="margin-left: 20px; margin-right:15px" href="<?php echo e(URL::to('/editTask/'.$v_task->id)); ?>"><?php echo e($v_task->title); ?></a></span>

              <span style="margin-left: 10px;" class="label label-warning label-mini">
                <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $v_task->updated_at)->diffForHumans()); ?>

                </span>
                <span style="margin-left: 5px; margin-right: 20px" class="label label-default label-mini">
                <?php echo e($v_task->lists->title); ?></span>
              <?php echo $__env->make('include.status', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

              </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              </table>
            </div>    
        </div>

        <div id="Menu4" style="display: none;">
            <div class="custom-check goleft mt">
              <table id="todo" class="table table-hover custom-check">
              <tbody>
              <h5  style="color:green"><b>Upcomming Task</b></h5>
              <?php $__currentLoopData = $upcommingTask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td>
              <?php echo $__env->make('include.priority', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
             <a style="margin-left: 20px;" href="<?php echo e(URL::to('/editTask/'.$v_task->id)); ?>">  <?php echo e($v_task->title); ?></a>
                <span style="margin-left: 10px;" class="label label-warning label-mini">
                <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $v_task->updated_at)->diffForHumans()); ?>

                </span>
                <span style="margin-left: 5px; margin-right: 20px" class="label label-default label-mini">
                <?php echo e($v_task->lists->title); ?></span>
                <?php echo $__env->make('include.status', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              </table>
            </div>    
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lib/admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>