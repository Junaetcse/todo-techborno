<?php $__env->startSection('main'); ?>
 <section id="main-content">
          <section class="wrapper">
<div id="login-page">
	<div class="container">
		<form class="form-login" method="POST" action="<?php echo e(route('login')); ?>">
		<?php echo csrf_field(); ?>
		    <h2 class="form-login-heading">Log in</h2>
		    <div class="login-wrap">   
				<br>
				<input id="email" type="email"  placeholder="User Email" class="form-control"  name="email" value="<?php echo e(old('email')); ?>" required autofocus>
				<?php if($errors->has('email')): ?>
				<span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('email')); ?></strong></span>
				<?php endif; ?><br>
				<input id="password" type="password" class="form-control" placeholder="Password"  name="password" required>
				<?php if($errors->has('password')): ?>
				<span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('password')); ?></strong></span>
				<?php endif; ?><br>		      
				<button class="btn btn-theme btn-block"  type="submit"><i class="fa fa-lock"></i> SIGN IN</button>
				<div class="registration"> Don't have an account yet?<br/>
				<a href="<?php echo e(route('register')); ?>">Create an account</a>
				</div>
		    </div>
		</form>	  	
	  	</div>
	  </div>
	</section>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('login'); ?>
   <!-- <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/login-bg.jpg", {speed: 500});
    </script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>