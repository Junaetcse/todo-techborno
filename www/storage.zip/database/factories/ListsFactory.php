<?php

use Faker\Generator as Faker;

$factory->define(App\lists::class, function (Faker $faker) {
    return [
        //
    ];
});
